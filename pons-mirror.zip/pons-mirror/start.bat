@echo off
cd /d %~dp0
:loop
node mirror.js
echo.
echo Бот остановился, перезапуск через 10 секунд... (Ctrl+C чтобы выйти)
timeout /t 10 >nul
goto loop
