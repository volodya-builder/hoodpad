@echo off
cd /d %~dp0
echo === Деплой hood в мейннет Robinhood Chain ===
echo Убедись, что заполнил deploy-config.json (ключ, rpc, кошелёк команды).
echo.
node deploy-mainnet.js
echo.
echo Готово. Адреса сохранены в mainnet-addresses.txt — пришли их Клоду.
pause
